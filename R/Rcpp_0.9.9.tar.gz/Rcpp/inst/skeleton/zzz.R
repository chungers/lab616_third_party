
.onLoad <- function(libname, pkgname) {
    require("methods", character=TRUE, quietly=TRUE)
    loadRcppModules()
}

