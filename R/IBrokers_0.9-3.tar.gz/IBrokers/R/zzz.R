`.onLoad` <- function(lib,pkg) {
  message("IBrokers version 0.9-3:")
  message("Implementing API Version 9.64")
  cat("This software comes with NO WARRANTY.  Not intended for production use!\n")
  message("See ?IBrokers for details")
}
